const apiUrl = "https://api.exchangerate-api.com/v4/latest/USD"; 

async function loadCurrencies() {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        const currencies = Object.keys(data.rates);
        const fromSelect = document.getElementById("from-currency");
        const toSelect = document.getElementById("to-currency");

        currencies.forEach(currency => {
            const option1 = document.createElement("option");
            option1.value = currency;
            option1.textContent = currency;

            const option2 = option1.cloneNode(true);

            fromSelect.appendChild(option1);
            toSelect.appendChild(option2);
        });

        fromSelect.value = "USD";  
        toSelect.value = "EUR";  

        fromSelect.addEventListener("change", convertCurrency);
        toSelect.addEventListener("change", convertCurrency);
        document.getElementById("amount").addEventListener("input", convertCurrency);
    } catch (error) {
        console.error("Error loading currencies", error);
    }
}

async function convertCurrency() {
    const amount = document.getElementById("amount").value;
    const fromCurrency = document.getElementById("from-currency").value;
    const toCurrency = document.getElementById("to-currency").value;
    const resultElement = document.getElementById("result");
    const rateElement = document.getElementById("rate");

    if (amount === "" || amount <= 0) {
        resultElement.innerHTML = "???? ????? ???? ????";
        return;
    }

    try {
        const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`);
        const data = await response.json();
        const rate = data.rates[toCurrency];
        const convertedAmount = (amount * rate).toFixed(2);

        resultElement.innerHTML = `?????? ??????: ${convertedAmount} ${toCurrency}`;
        rateElement.innerHTML = `??? ????? ?????: 1 ${fromCurrency} = ${rate} ${toCurrency}`;
    } catch (error) {
        resultElement.innerHTML = "??? ??? ????? ??? ????????.";
        console.error("Error fetching exchange rate", error);
    }
}

window.onload = loadCurrencies;